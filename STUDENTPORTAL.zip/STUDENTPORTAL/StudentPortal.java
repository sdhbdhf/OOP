import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import javax.imageio.ImageIO;

class FoodItem {
    String name;
    int price;
    String imagePath;
    String description;

    public FoodItem(String name, int price, String imagePath, String description) {
        this.name = name;
        this.price = price;
        this.imagePath = imagePath;
        this.description = description;
    }
}

public class StudentPortal extends JFrame {
    private static final Color PRIMARY_COLOR = new Color(255, 165, 0);
    private static final Color SECONDARY_COLOR = new Color(220, 220, 220);
    private static final Color TEXT_COLOR = new Color(50, 50, 50);
    private static final Color BACKGROUND_COLOR = Color.WHITE;

    private JPanel mainPanel, menuPanel, orderPanel, headerPanel;
    private JTextArea cartArea;
    private int total = 0;
    private JLabel userGreetingLabel;
    private Map<String, FoodItem> foodItems;

    public StudentPortal() {
        initializeFoodItems();
        createMainFrame();
        showMainMenu();
    }

    private void initializeFoodItems() {
        foodItems = new HashMap<>();
        foodItems.put("beyaynet", new FoodItem("Beyaynet", 80, "images/beyaynet.jpg", "Traditional Ethiopian mixed dish with various stews and vegetables"));
        foodItems.put("pasta", new FoodItem("Pasta", 80, "images/pasta.jpg", "Italian style pasta with your choice of sauce"));
        foodItems.put("shiro", new FoodItem("Shiro", 70, "images/shiro.jpg", "Flavorful Ethiopian chickpea stew served with injera"));
        foodItems.put("tibs", new FoodItem("Tibs", 70, "images/tibs.jpg", "Sautéed meat dish with onions, peppers and Ethiopian spices"));
        foodItems.put("firfir", new FoodItem("Firfir", 80, "images/firfir.jpg", "Shredded injera mixed with spicy sauce"));
        foodItems.put("ertib", new FoodItem("Ertib", 50, "images/ertib.jpg", "Simple spiced lentil dish"));
        foodItems.put("egg sandwich", new FoodItem("Egg Sandwich", 60, "images/eggsandwich.jpg", "Boiled egg sandwich with Ethiopian spices"));
    }

    private void createMainFrame() {
        setTitle("Student Food Portal");
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BACKGROUND_COLOR);
        add(mainPanel);
    }

    private void showMainMenu() {
        mainPanel.removeAll();
        headerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        userGreetingLabel = new JLabel("Welcome to UniEats Cafe!");
        userGreetingLabel.setForeground(Color.WHITE);
        userGreetingLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));

        headerPanel.add(userGreetingLabel);
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        menuPanel = new JPanel(new GridLayout(0, 2, 10, 10));
        menuPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        menuPanel.setBackground(BACKGROUND_COLOR);

        JScrollPane scrollPane = new JScrollPane(menuPanel);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        orderPanel = new JPanel(new BorderLayout());
        orderPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        orderPanel.setBackground(SECONDARY_COLOR);

        cartArea = new JTextArea(10, 20);
        cartArea.setEditable(false);
        cartArea.setText("Your Order:\n");

        JButton checkoutBtn = new JButton("Checkout");
        checkoutBtn.setBackground(PRIMARY_COLOR);
        checkoutBtn.setForeground(Color.WHITE);
        checkoutBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Total Amount: " + total + " Birr\nThank you for ordering!");
            cartArea.setText("Your Order:\n");
            total = 0;
        });

        orderPanel.add(new JScrollPane(cartArea), BorderLayout.CENTER);
        orderPanel.add(checkoutBtn, BorderLayout.SOUTH);

        mainPanel.add(orderPanel, BorderLayout.EAST);

        createMenuContent();
        revalidate();
        repaint();
    }

    private void createMenuContent() {
        menuPanel.removeAll();
        List<FoodItem> itemList = new ArrayList<>(foodItems.values());
        for (FoodItem item : itemList) {
            JPanel card = new JPanel(new BorderLayout());
            card.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));

            JLabel nameLabel = new JLabel(item.name);
            nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
            nameLabel.setForeground(TEXT_COLOR);

            JLabel priceLabel = new JLabel(item.price + " Birr");
            priceLabel.setForeground(PRIMARY_COLOR);

            JLabel imgLabel = new JLabel();
            imgLabel.setHorizontalAlignment(SwingConstants.CENTER);
            imgLabel.setPreferredSize(new Dimension(150, 150));
            try {
                Image image = ImageIO.read(new File(item.imagePath));
                Image scaled = image.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
                imgLabel.setIcon(new ImageIcon(scaled));
            } catch (Exception e) {
                imgLabel.setText("[No Image]");
                imgLabel.setHorizontalAlignment(SwingConstants.CENTER);
            }

            JTextArea descArea = new JTextArea(item.description);
            descArea.setWrapStyleWord(true);
            descArea.setLineWrap(true);
            descArea.setEditable(false);
            descArea.setOpaque(false);

            JButton orderBtn = new JButton("Order");
            orderBtn.setBackground(PRIMARY_COLOR);
            orderBtn.setForeground(Color.WHITE);
            orderBtn.addActionListener(e -> {
                cartArea.append("- " + item.name + ": " + item.price + " Birr\n");
                total += item.price;
            });

            JPanel bottom = new JPanel(new BorderLayout());
            bottom.add(nameLabel, BorderLayout.NORTH);
            bottom.add(priceLabel, BorderLayout.CENTER);
            bottom.add(orderBtn, BorderLayout.SOUTH);

            card.add(imgLabel, BorderLayout.NORTH);
            card.add(descArea, BorderLayout.CENTER);
            card.add(bottom, BorderLayout.SOUTH);

            menuPanel.add(card);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new StudentPortal().setVisible(true));
    }
}
